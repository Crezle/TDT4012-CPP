#include "task1.h"
#include "task2.h"
#include "LinkedList.h"
#include "task4.h"



int main()
{
	srand(time(nullptr));
	/* std::vector<std::string> VecOfStrings{"Lorem", "Ipsum", "Dolor", "Sit", "Amet", "Consectetur"}; */
	/* std::set<std::string> SetOfStrings{"Lorem", "Ipsum", "Dolor", "Sit", "Amet", "Consectetur"}; */

	/* vectorIterator(VecOfStrings); */
	/* reverseVectorIterator(VecOfStrings); */
	/* replace(&VecOfStrings, "Dolor", "MoneyMoney"); */
	/* vectorIterator(VecOfStrings); */

	/* setIterator(SetOfStrings); */
	/* reverseSetIterator(SetOfStrings); */
	/* setReplace(SetOfStrings, "Dolor", "MoneyMoney"); */
	/* setIterator(SetOfStrings); */

	/* Person Christian("Christian", "Le");
	Person Kristian("Kristian", "Karstad");
	Person Truls("Truls","Eftedal");
	Person Mac("Mathias", "Ringdal");
	Person Strom("Christopher", "Strom");

	std::list<Person> l;

	insertOrdered(l, Kristian);
	insertOrdered(l, Christian);
	insertOrdered(l, Truls);
	insertOrdered(l, Mac);
	insertOrdered(l, Strom);
	
	showList(l); */

	testLinkedList();

	/* std::cout << maximum(1,2) << std::endl; */
	/* std::cout << maximum(1.1,2.1) << std::endl; */

	/* std::vector<std::string> v = {"A","B","C","D"};
	shuffle(v);
	for (int i = 0; i < v.size(); i++) {
		std::cout << v[i] << '\n';
	} */


	return 0;
}