#pragma once

// 1a)

void fillInFibonacciNumbers(int result[], int length);

// 1b)

void printArray(int arr[], int length);

// 1c)

void createFibonacci();