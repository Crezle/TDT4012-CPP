#pragma once
// 5a, b og c)

int randomWithLimits(int lowerLimit, int upperLimit);

// 5d)

void playTargetPractice();