#include "std_lib_facilities.h"
#include "animal.h"
#include "Graph.h"

using namespace Graph_lib;

/* int main()
{
	Cat cat("Multe", 15);
	Dog dog("Poopsock", 2);
	Vector_ref<Animal> v;
	v.push_back(cat);
	v.push_back(dog);

	testAnimal(v);
} */