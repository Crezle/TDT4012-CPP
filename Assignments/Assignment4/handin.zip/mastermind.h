#include "std_lib_facilities.h"

// 4a)

void playMastermind();

// 4e)

int checkCharactersAndPosition(string code, string guess);

// 4f)

int checkCharacters(string code, string guess);