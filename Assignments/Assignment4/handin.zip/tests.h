#include "std_lib_facilities.h"

// 1c)

void testCallByValue();

// 1d)

void testCallByReference();

// 3a)

void testString();

