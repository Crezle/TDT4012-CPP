#include "std_lib_facilities.h"
#include <iostream>
using namespace std;

// 1a)

void writeToFile();

// 1b)

void readLineNum(string textfile);

// 2a)

void sortByChar(string textfile);